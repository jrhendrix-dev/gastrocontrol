package com.gastrocontrol.gastrocontrol.domain.enums;

public enum PaymentProvider {
    STRIPE
}
