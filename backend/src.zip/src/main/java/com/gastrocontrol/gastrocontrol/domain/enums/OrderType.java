package com.gastrocontrol.gastrocontrol.domain.enums;

/**
 * Type of service for an order.
 */
public enum OrderType {
    DINE_IN,
    TAKE_AWAY,
    DELIVERY
}
