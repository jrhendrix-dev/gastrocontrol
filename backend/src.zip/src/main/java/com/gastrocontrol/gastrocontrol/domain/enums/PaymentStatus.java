package com.gastrocontrol.gastrocontrol.domain.enums;

public enum PaymentStatus {
    REQUIRES_PAYMENT,
    SUCCEEDED,
    EXPIRED,
    CANCELLED
}

