package com.gastrocontrol.gastrocontrol.domain.enums;

public enum OrderEventReasonCode {
    CORRECTION,
    CUSTOMER_REQUEST,
    KITCHEN_ERROR
}
