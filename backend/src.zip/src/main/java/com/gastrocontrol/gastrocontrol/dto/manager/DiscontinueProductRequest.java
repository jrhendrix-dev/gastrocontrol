// src/main/java/com/gastrocontrol/gastrocontrol/dto/manager/DiscontinueProductRequest.java
package com.gastrocontrol.gastrocontrol.dto.manager;

public class DiscontinueProductRequest {

    private String reason;

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}
