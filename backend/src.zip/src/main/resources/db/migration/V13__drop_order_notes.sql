DROP TABLE IF EXISTS order_notes;
